//
//  zh_AppDelegate.h
//  zhPopupController
//
//  Created by snail-z on 08/17/2016.
//  Copyright (c) 2017 snail-z. All rights reserved.
//

@import UIKit;

@interface zh_AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

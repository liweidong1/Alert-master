//
//  UINavigationBar+BackgroundColor.h
//  categoryKitDemo
//
//  Created by zhanghao on 2016/7/23.
//  Copyright © 2016年 zhanghao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (BackgroundColor)

- (void)sl_setBackgroundColor:(UIColor *)backgroundColor;
- (void)sl_reset;

@end

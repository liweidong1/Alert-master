//
//  main.m
//  zhPopupController
//
//  Created by snail-z on 08/17/2017.
//  Copyright (c) 2017 snail-z. All rights reserved.
//

@import UIKit;
#import "zh_AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([zh_AppDelegate class]));
    }
}
